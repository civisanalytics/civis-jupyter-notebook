import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { ISettingRegistry } from '@jupyterlab/settingregistry';

import { downloadIcon, terminalIcon } from '@jupyterlab/ui-components';
import { TerminalManager } from '@jupyterlab/services';
import {} from '@jupyterlab/terminal-extension';

/**
 * Initialization data for the civis-jupyter-notebook-extensions extension.
 */

// commands
// https://jupyterlab.readthedocs.io/en/stable/user/commands.html
// classes
// https://jupyterlab.readthedocs.io/en/stable/api/classes/ui_components.ToolbarButton.html
// icons
// https://github.com/jupyterlab/jupyterlab/blob/main/packages/ui-components/src/icon/iconimports.ts
// extension points
// https://jupyterlab.readthedocs.io/en/latest/extension/extension_points.html#toolbar-item

const plugin: JupyterFrontEndPlugin<void> = {
  id: 'civis-jupyter-notebook-extensions:plugin',
  description: 'Extensions for use in Jupyter Notebook in Civis Platform.',
  autoStart: true,
  optional: [ISettingRegistry],
  activate: (app: JupyterFrontEnd, settingRegistry: ISettingRegistry | null) => {
    console.log('JupyterLab extension civis-jupyter-notebook-extensions is activated!');

    const { commands } = app;
    commands.addCommand('assignments:submit', {
      label: 'Submit for Grading',
      iconLabel: 'Submit for Grading',
      icon: downloadIcon,
      execute: () => {
        console.log('Hello World!');
      }
    });

    commands.addCommand('civis:open-terminal', {
      label: 'Open Teminal',
      iconLabel: 'Open Terminal',
      icon: terminalIcon,
      execute: async () => {
        const manager = new TerminalManager();
        await manager.ready;
        console.log('Terminal manager is ready:', manager.isReady);
        // const names = manager.names()
        // const term = manager.startNew({ name: 'civis-terminal' });
        // const runningChanged = app.sessions.values();
        // runningChanged.connect((sender, models) => {
        //   console.log('Running terminals changed:', models);
        // });
        // console.log(runningChanged);

        console.log('Running terminals:', manager.running);
        // displayPopUp1("Terminal will open now with script");

        console.log('Hello terminal!');
        // app.commands.execute('terminal:open');
        app.commands.execute('terminal:open term');
      }
    });

    if (settingRegistry) {
      settingRegistry
        .load(plugin.id)
        .then(settings => {
          console.log('civis-jupyter-notebook-extensions settings loaded:', settings.composite);
        })
        .catch(reason => {
          console.error('Failed to load settings for civis-jupyter-notebook-extensions.', reason);
        });
    }
  }
};

export default plugin;
