"use strict";
(self["webpackChunkcivis_jupyter_notebook_extensions"] = self["webpackChunkcivis_jupyter_notebook_extensions"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/terminal */ "webpack/sharing/consume/default/@jupyterlab/terminal");
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _intialLoad__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./intialLoad */ "./lib/intialLoad.js");

 //






const plugin = {
    id: 'civis-jupyter-notebook-extensions:plugin',
    description: 'Extensions for use in Jupyter Notebook in Civis Platform.',
    autoStart: true,
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    activate: (app, settingRegistry) => {
        console.log('Civis JupyterLab extension is activated!');
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(settings => {
                console.log('Civis JupyterLab extension settings loaded:', settings.composite);
                (0,_intialLoad__WEBPACK_IMPORTED_MODULE_6__.initScreenSettings)(app);
            })
                .catch(reason => {
                console.error('Failed to load Civis JupyterLab extension settings.', reason);
            });
        }
        const { commands } = app;
        const closeTerminalButton = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.ToolbarButton({ label: 'Close Terminal' });
        closeTerminalButton.id = 'civis-close-terminal-button';
        closeTerminalButton.node.innerHTML = 'Notebook';
        closeTerminalButton.node.prepend(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.caretLeftIcon.element({
            tag: 'span',
            className: 'civis-jp-Icon civis-jp-Icon-20'
        }));
        closeTerminalButton.node.onclick = () => {
            const terminalPanel = app.shell.currentWidget;
            if (terminalPanel) {
                terminalPanel.dispose();
            }
        };
        commands.addCommand('civis:show-keyboard-shortcuts', {
            label: 'Show Keyboard Shortcuts',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.keyboardIcon,
            execute: async () => {
                commands.execute('apputils:display-shortcuts');
            }
        });
        // create a widget to hold the close terminal button
        const civisTerminalToolbarWidget = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__.Widget();
        civisTerminalToolbarWidget.id = 'civis-terminal-toolbar';
        civisTerminalToolbarWidget.title.label = 'Terminal Toolbar';
        civisTerminalToolbarWidget.node.appendChild(closeTerminalButton.node);
        const manager = new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__.TerminalManager();
        // add command to open terminal, which is called in plugin.json
        commands.addCommand('civis:open-terminal', {
            label: 'Open Teminal',
            iconLabel: 'Open Terminal',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.terminalIcon,
            execute: async () => {
                // create a dialog box to show while terminal is loading
                const terminalMessage = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__.Dialog({
                    title: 'Loading Terminal',
                    body: new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.Spinner(),
                    buttons: []
                });
                terminalMessage.launch();
                // open existing terminal if api returns terminals or create a new one and load it in the main area of the widget
                try {
                    const api = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__.TerminalAPI;
                    const terminalList = await api.listRunning();
                    // reference: https://github.com/jupyterlab/extension-examples/tree/main/custom-log-console
                    let terminal = null;
                    if (terminalList.length > 0) {
                        terminal = new _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__.Terminal(manager.connectTo({
                            model: { name: terminalList[0].name }
                        }));
                    }
                    else {
                        const termPanel = await manager.startNew();
                        terminal = new _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__.Terminal(manager.connectTo({ model: termPanel.model }));
                    }
                    // add the terminal toolbar to the terminal widget
                    terminal.node.appendChild(civisTerminalToolbarWidget.node);
                    const terminalPanelWidget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__.MainAreaWidget({
                        content: terminal
                    });
                    // close the dialog box and open the terminal in the main area
                    terminalMessage.dispose();
                    app.shell.add(terminalPanelWidget, 'main');
                }
                catch (error) {
                    // to do: add better error handling, including error message to Notifications
                    // notifications: https://github.com/jupyterlab/extension-examples/tree/main/notifications
                    console.error('Error opening terminal:', error);
                    terminalMessage.dispose();
                }
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/intialLoad.js":
/*!***************************!*\
  !*** ./lib/intialLoad.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initScreenSettings: () => (/* binding */ initScreenSettings)
/* harmony export */ });
const initScreenSettings = (app) => {
    setTimeout(() => {
        var _a, _b;
        if (!((_a = document
            .getElementById('jp-top-panel')) === null || _a === void 0 ? void 0 : _a.classList.contains('lm-mod-hidden'))) {
            app.commands.execute('application:toggle-header');
        }
        if (!((_b = document
            .getElementById('jp-main-statusbar')) === null || _b === void 0 ? void 0 : _b.classList.contains('lm-mod-hidden'))) {
            app.commands.execute('statusbar:toggle');
        }
    }, 250);
};


/***/ })

}]);
//# sourceMappingURL=lib_index_js.297ac283487eda200cc5.js.map