"use strict";
(self["webpackChunkcivis_jupyter_notebook_extensions"] = self["webpackChunkcivis_jupyter_notebook_extensions"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/terminal */ "webpack/sharing/consume/default/@jupyterlab/terminal");
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__);

 //


// import { ITerminal } from '@jupyterlab/services/lib/terminal/terminal';


// import { NotebookActions } from '@jupyterlab/notebook';

// import { MainAreaWidget } from '@jupyterlab/apputils';
// import { Widget } from '@lumino/widgets';
// import {} from '@jupyterlab/terminal-extension';
/**
 * Initialization data for the civis-jupyter-notebook-extensions extension.
 */
// extension examples: https://github.com/jupyterlab/extension-examples
// commands
// https://jupyterlab.readthedocs.io/en/stable/user/commands.html
// classes
// https://jupyterlab.readthedocs.io/en/stable/api/classes/ui_components.ToolbarButton.html
// icons
// https://github.com/jupyterlab/jupyterlab/blob/main/packages/ui-components/src/icon/iconimports.ts
// extension points
// https://jupyterlab.readthedocs.io/en/latest/extension/extension_points.html#toolbar-item
// interface (toolbars, menus, etc) customization
// https://jupyterlab.readthedocs.io/en/latest/user/interface_customization.html
const plugin = {
    id: 'civis-jupyter-notebook-extensions:plugin',
    description: 'Extensions for use in Jupyter Notebook in Civis Platform.',
    autoStart: true,
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    activate: (app, settingRegistry) => {
        console.log('Civis JupyterLab extension is activated!');
        //load settings from the setting registry /schema/plugin.json
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(settings => {
                console.log('Civis JupyterLab extension settings loaded:', settings.composite);
            })
                .catch(reason => {
                console.error('Failed to load Civis JupyterLab extension settings.', reason);
            });
        }
        const { commands } = app;
        commands.addCommand('assignments:submit', {
            label: 'Submit for Grading',
            iconLabel: 'Submit for Grading',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.downloadIcon,
            execute: () => {
                console.log('Hello World!');
            }
        });
        // create close terminal button and it's function for use in terminal "toolbar"
        // try to get this into the actual toolbar available from MainWidgetArea,
        // possibly using this as reference: https://github.com/jupyterlab/extension-examples/blob/main/contentheader/README.md
        const closeTerminalButton = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.ToolbarButton({ label: 'Close Terminal' });
        closeTerminalButton.id = 'civis-close-terminal-button';
        closeTerminalButton.node.innerHTML = 'Notebook';
        closeTerminalButton.node.prepend(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.caretLeftIcon.element({
            tag: 'span',
            className: 'civis-jp-Icon civis-jp-Icon-20'
        }));
        closeTerminalButton.node.onclick = () => {
            const terminalPanel = app.shell.currentWidget;
            if (terminalPanel) {
                terminalPanel.dispose();
            }
        };
        // create a widget to hold the close terminal button
        const civisTerminalToolbarWidget = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__.Widget();
        civisTerminalToolbarWidget.id = 'civis-terminal-toolbar';
        civisTerminalToolbarWidget.title.label = 'Terminal Toolbar';
        civisTerminalToolbarWidget.node.appendChild(closeTerminalButton.node);
        const manager = new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__.TerminalManager();
        // add command to open terminal, which is called in plugin.json
        commands.addCommand('civis:open-terminal', {
            label: 'Open Teminal',
            iconLabel: 'Open Terminal',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.terminalIcon,
            execute: async () => {
                // create a dialog box to show while terminal is loading
                const terminalMessage = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__.Dialog({
                    title: 'Loading Terminal',
                    body: new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.Spinner(),
                    buttons: []
                });
                terminalMessage.launch();
                // open existing terminal if api returns terminals or create a new one and load it in the main area of the widget
                try {
                    // const manager = new TerminalManager();
                    const api = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_2__.TerminalAPI;
                    const terminalList = await api.listRunning();
                    // create widget to hold terminal toolbar and add it to MainAreaWidget
                    // reference: https://github.com/jupyterlab/extension-examples/tree/main/custom-log-console
                    let terminal = null;
                    if (terminalList.length > 0) {
                        terminal = new _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__.Terminal(manager.connectTo({
                            model: { name: terminalList[0].name }
                        }));
                    }
                    else {
                        const termPanel = await manager.startNew();
                        terminal = new _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_3__.Terminal(manager.connectTo({ model: termPanel.model }));
                    }
                    // add the terminal toolbar to the terminal widget
                    terminal.node.appendChild(civisTerminalToolbarWidget.node);
                    const terminalPanelWidget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_5__.MainAreaWidget({
                        content: terminal
                    });
                    // close the dialog box and open the terminal in the main area
                    terminalMessage.dispose();
                    app.shell.add(terminalPanelWidget, 'main');
                }
                catch (error) {
                    // to do: add better error handling, including error message to Notifications
                    // notifications: https://github.com/jupyterlab/extension-examples/tree/main/notifications
                    console.error('Error opening terminal:', error);
                    terminalMessage.dispose();
                }
                // message.launch();
                // if (terminalList.length > 0) {
                //   console.log('Connecting to existing terminal:', terminalList[0].name);
                //   manager.connectTo({
                //     model: { name: terminalList[0].name.toString() }
                //   });
                //   const node = document.createElement('div');
                //   node.textContent = 'Hello World';
                //   const main = app.shell.currentWidget;
                //   if (main instanceof MainAreaWidget) {
                //     // Create a widget
                //     // const widget = new Widget();
                //     // widget.addClass('example-extension-contentheader-widget');
                //     // widget.node.textContent = "hello world!";
                //     // widget.node.style.color = 'red';
                //     // widget.node.style.backgroundColor = 'yellow';
                //     // widget.node.style.position = 'relative';
                //     // // set the height so that it is visible
                //     // widget.node.style.minHeight = '20px';
                //     // widget.node.style.display = 'block';
                //     // // const mainPanel = document.getElementById('jp-main-dock-panel');
                //     // // and insert it into the header
                //     // commands.execute('terminal:open');
                //     // document.insertBefore(widget.node, mainPanel);
                //     // const mainMenu = document.getElementById('jp-MainMenu');
                //     // mainMenu?.insertAdjacentElement('beforeend', widget.node);
                //     // setTimeout(() => {
                //     //   const mainPanel = document.getElementById('jp-main-dock-panel');
                //     //   mainPanel?.parentElement?.appendChild(widget.node);
                //     //   const terminalDisplay =
                //     //     mainPanel && mainPanel.querySelector('[role]="tabpanel"');
                //     //   if (terminalDisplay) {
                //     //     (terminalDisplay as HTMLElement).style.top = '20px';
                //     //   }
                //     // }, 15000);
                //   }
                //   // Create the widget
                //   // const widget = new Widget({ node });
                //   // const TOP_AREA_CSS_CLASS = 'jp-TopAreaText';
                //   // widget.id = DOMUtils.createDomID();
                //   // widget.addClass(TOP_AREA_CSS_CLASS);
                //   // // Add the widget to the top area
                //   // app.shell.add(widget, 'top', { rank: 1000 });
                //   // console.log('window location', window.location.href);
                //   // const start = api.startNew();
                //   // start.then((model: any) => {
                //   //   console.log('model', model);
                //   //   model.name = terminalList[0].name;
                //   //   manager.connectTo({
                //   //     model: model
                //   //   });
                //     // const terminal = manager.connectTo({ model: model });
                //     // const widget = new MainAreaWidget({ content: terminal });
                //     // app.shell.add(widget);
                //     // console.log('router', router);
                //     // router.navigate('/terminals/' + model.name, { hard: true });
                // } else {
                //   console.log('starting new terminal');
                //   manager.startNew();
                // }
                // setTimeout(() => {
                //   message.dispose();
                // }, 2000);
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.1f534c41ab847de7da4a.js.map